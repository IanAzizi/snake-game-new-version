package org.example;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import java.awt.*;

public class SnakeGame extends JPanel implements ActionListener, KeyListener {
    int bordWidth;
    int bordHeight;
    int tile = 25;

    private class Tile {
        int x;
        int y;

        Tile(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    Tile snakeHead;
    Tile food;
    Random random;

    Timer gameLoop;
    int velocity_X;
    int velocity_Y;
    int velocity_Z;
    int velocity_W;
    ArrayList<Tile>  snakeBody;

    SnakeGame(int bordHeight, int bordWidth) {
        this.bordHeight = bordHeight;
        this.bordWidth = bordWidth;
        setPreferredSize(new Dimension(bordWidth, bordHeight));
        setBackground(Color.black);

        snakeHead = new Tile(5, 5);
        food = new Tile(10, 10);
        random = new Random();
        placeFood();

        // Initialize velocities
        velocity_X = 0; // Initially not moving
        velocity_Y = 0;
        velocity_W = 0;// Initially moving down
        velocity_Z = 0;

        // Create and start the game loop
        gameLoop = new Timer(100, this);
        gameLoop.start(); // Start the timer

        addKeyListener(this); // Register the KeyListener
        setFocusable(true); // Allow the component to gain focus
        addKeyListener(this);
        setFocusable(true);
        snakeBody = new ArrayList<Tile>();
    }

    public void paint(Graphics g) {
        super.paint(g);
        draw(g);
    }

    public void draw(Graphics g) {
        // Draw grid
        for (int i = 0; i < bordWidth/tile; i++) {
            g.drawLine(i * tile, 0, i * tile, bordHeight);
            g.drawLine(0, i * tile, bordWidth, i * tile);
        }

        // Draw food
        g.setColor(Color.red);
        g.fillRect(food.x * tile, food.y * tile, tile, tile);

        // Draw snake head
        g.setColor(Color.green);
        g.fillRect(snakeHead.x * tile, snakeHead.y * tile, tile, tile);


        for (int i = 0; i <snakeBody.size(); i++) {
            Tile snakePart = snakeBody.get(i);
            g.fillRect(snakePart.x*tile, snakePart.y*tile, tile, tile );

        }
    }

    public void placeFood() {
        //food.x = random.nextInt(bordWidth / tile);
      //  food.y = random.nextInt(bordHeight / tile);


    }

    public void move() {
        // Update snake head position
        snakeHead.x += velocity_X;
        snakeHead.y += velocity_Y;
        food.x += velocity_W;//left and right
        food.y += velocity_Z;//up and down
        // Keep snake within the bounds of the board
        if (snakeHead.x < 0) snakeHead.x = (bordWidth / tile) - 1; // Wrap around
        if (snakeHead.x >= (bordWidth / tile)) snakeHead.x = 0; // Wrap around
        if (snakeHead.y < 0) snakeHead.y = (bordHeight / tile) - 1; // Wrap around
        if (snakeHead.y >= (bordHeight / tile)) snakeHead.y = 0;
        if (food.x < 0) food.x = (bordWidth / tile) - 1; // Wrap around
        if (food.x >= (bordWidth / tile)) food.x = 0; // Wrap around
        if (food.y < 0) food.y = (bordHeight / tile) - 1; // Wrap around
        if (food.y >= (bordHeight / tile)) snakeHead.y = 0; // Wrap around
        if (collision(snakeHead,food)){
            snakeBody.add(snakeHead);
            placeFood();
        }
    }
    public boolean collision(Tile tile1, Tile tile2){
        return tile1.x == tile2.x && tile1.y == tile2.y;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        // Change direction based on key pressed
        if (e.getKeyCode() == KeyEvent.VK_UP && velocity_Y != 1) {
            velocity_X = 0;
            velocity_Y = -1;
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN && velocity_Y != -1) {
            velocity_X = 0;
            velocity_Y = 1;
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT && velocity_X != 1) {
            velocity_X = -1;
            velocity_Y = 0;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && velocity_X != -1) {
            velocity_X = 1;
            velocity_Y = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_W && velocity_Y != 1) {
            velocity_W = 0;
            velocity_Z = -1;
        } else if (e.getKeyCode() == KeyEvent.VK_S && velocity_Y != -1) {
            velocity_W = 0;
            velocity_Z = 1;
        } else if (e.getKeyCode() == KeyEvent.VK_D && velocity_X != 1) {
            velocity_W = -1;
            velocity_Z = 0;
        } else if (e.getKeyCode() == KeyEvent.VK_A && velocity_X != -1) {
            velocity_W = 1;
            velocity_Z = 0;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        SnakeGame snakeGame = new SnakeGame(400, 400);
        frame.add(snakeGame);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

}