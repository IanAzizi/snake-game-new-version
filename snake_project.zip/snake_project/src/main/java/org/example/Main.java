package org.example;
import javax.swing.*;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("snake");
                int bordWidth = 600;
                int bordHeight = bordWidth;
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                frame.setResizable(false);
                frame.setSize(bordWidth, bordHeight);
               frame.setLocationRelativeTo(null);

               SnakeGame snakegame = new SnakeGame(bordWidth, bordHeight);
               frame.add(snakegame);
               frame.pack();
               snakegame.requestFocus();
    }
}